package com.capg.paymentwallet.ui;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.capg.paymentwallet.bean.AccountBean;
import com.capg.paymentwallet.bean.CustomerBean;
import com.capg.paymentwallet.bean.WalletTransaction;
import com.capg.paymentwallet.exception.CustomerException;
import com.capg.paymentwallet.service.AccountServiceImpl;
import com.capg.paymentwallet.service.IAccountService;

public class Client {

	IAccountService service = new AccountServiceImpl();
	CustomerBean customer = new CustomerBean();
	Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) throws Exception {
		char ch;
		Client client = new Client();
		try {
			do {
				System.out.println("========Payment wallet application========");
				System.out.println("1. Create Account ");
				System.out.println("2. Show Balance ");
				System.out.println("3. Deposit ");
				System.out.println("4. Withdraw ");
				System.out.println("5. Fund Transfer");
				System.out.println("6. Print Transactions");
				System.out.println("7. Exit");
				System.out.println("Choose an option");
				int option = client.scanner.nextInt();

				switch (option) {
				case 1:
					client.create();
					break;
				case 2:
					client.showbalance();

					break;

				case 3:
					client.deposit();

					break;

				case 4:
					client.withdraw();

					break;

				case 5:
					client.fundtransfer();

					break;

				case 6:
					client.printTransaction();

					break;
				case 7:
					System.exit(0);

					break;

				default:
					System.out.println("\ninvalid option\n");
					break;
				}

				System.out.print("\n\tDo you want to continue press Y/N\n\t");
				ch = client.scanner.next().charAt(0);

			} while (ch == 'y' || ch == 'Y');
		} catch (CustomerException e) {
			System.out.println(e.getMessage());
		}

	}

	void create() throws Exception {

		System.out.print("\tEnter Customer firstname\t:");
		String fname = scanner.next();

		System.out.print("\tEnter Customer lastname\t:");
		String lname = scanner.next();

		System.out.print("\tEnter  Customer  email id\t:");
		String email = scanner.next();

		System.out.print("\tEnter  Customer  phone number\t:");
		String phone = scanner.next();

		System.out.print("\tEnter  Customer PAN number\t:");
		String pan = scanner.next();

		System.out.print("\tEnter  Customer  address\t:");
		scanner.nextLine();
		String address = scanner.nextLine();

		CustomerBean customerBean = new CustomerBean();
		customerBean.setAddress(address);
		customerBean.setEmailId(email);
		customerBean.setPanNum(pan);
		customerBean.setPhoneNo(phone);
		customerBean.setFirstName(fname);
		customerBean.setLastName(lname);

		System.out.print("\tEnter balance to create account\t:");
		double balance = scanner.nextDouble();

		AccountBean accountBean = new AccountBean();

		accountBean.setBalance(balance);
		accountBean.setDateOfOpening(new Date());
		accountBean.setInitialDeposit(balance);
		accountBean.setCustomerBean(customerBean);

		boolean result = service.createAccount(accountBean);

		if (result) {
			System.out.print("\n\t Account has been created successfully...\n\t");
			System.out.println(accountBean);
		} else {
			System.out.print("\n\tEnter valid details..\n\t");
		}
	}

	void showbalance() throws CustomerException, Exception {
		System.out.print("\tEnter Account ID\t:");
		int accId = scanner.nextInt();

		AccountBean accountBean = service.findAccount(accId);

		if (accountBean == null) {
			System.out.print("Account Does not exist");
			return;
		}

		System.out.print("\n\t Account holder name \t:" + accountBean.getCustomerBean().getFirstName() + "\n\t");
		System.out.print("\n\t Account holder's address \t:" + accountBean.getCustomerBean().getAddress() + "\n\t");
		System.out.print("\n\t Current Balance \t:" + accountBean.getBalance() + "\n\t");

	}

	void deposit() throws Exception {
		System.out.print("\tEnter Account ID\t:");
		int accId = scanner.nextInt();

		AccountBean accountBean = service.findAccount(accId);

		if (accountBean == null) {
			System.out.println("\n\tAccount Does not exist\n\t");
			return;
		}

		System.out.print("\n\t Account holder name \t:" + accountBean.getCustomerBean().getFirstName() + "\n\t");
		System.out.print("\n\t Account holder's address \t:" + accountBean.getCustomerBean().getAddress() + "\n\t");
		System.out.print("\n\t Current Balance \t:" + accountBean.getBalance() + "\n\t");

		System.out.print("\n\tEnter amount that you want to deposit\t:");

		double depositAmt = scanner.nextDouble();
		WalletTransaction wt = new WalletTransaction();
		wt.setTransactionType("Deposit");
		wt.setTransactionDate(new Date());
		wt.setBalance(accountBean.getBalance()+depositAmt);
		wt.setTransactionAmt(depositAmt);
		wt.setBeneficiaryAccountBean(null);

		accountBean.addTransation(wt);

		double balance = service.deposit(accountBean, depositAmt);

		
		if (balance >= 0) {
			System.out.println(
					"\n\tMoney is deposited into " + accountBean.getCustomerBean().getFirstName() + "'s Account \n\t");

			System.out.println("\n\tcurrent balance : " + accountBean.getBalance() + "\n\t");
		} else {
			System.out.println("\n\tMoney is NOT Deposited into " + accountBean.getCustomerBean().getFirstName()
					+ "'s Account\n\t ");
		}

	}

	void withdraw() throws Exception {
		System.out.print("\tEnter Account ID\t:");
		int accId = scanner.nextInt();

		AccountBean accountBean = service.findAccount(accId);
		if (accountBean == null) {
			System.out.println("\n\tAccount Does not exist\n\t");
			return;
		}

		System.out.print("\n\t Account holder name \t:" + accountBean.getCustomerBean().getFirstName() + "\n\t");
		System.out.print("\n\t Account holder's address \t:" + accountBean.getCustomerBean().getAddress() + "\n\t");
		System.out.print("\n\t Current Balance \t:" + accountBean.getBalance() + "\n\t");
		System.out.print("\n\tEnter amount that you want to withdraw\t");

		double withdrawAmt = scanner.nextDouble();
		if(withdrawAmt<accountBean.getBalance()){
		WalletTransaction wt = new WalletTransaction();
		wt.setTransactionType("withdraw");
		wt.setTransactionDate(new Date());
		wt.setBalance(accountBean.getBalance()-withdrawAmt);
		wt.setTransactionAmt(withdrawAmt);
		wt.setBeneficiaryAccountBean(null);

		accountBean.addTransation(wt);
		double balance = service.withdraw(accountBean, withdrawAmt);

		
		if (balance >=0) {
			System.out.print(
					"\n\tMoney is withdrawn from " + accountBean.getCustomerBean().getFirstName() + "'s Account \n\t");

			System.out.println("\n\tcurrent balance : " + accountBean.getBalance() + "\n\t");
		} else {
			System.out.print("\n\tMoney is NOT withdrawn from " + accountBean.getCustomerBean().getFirstName()
					+ "'s Account\n\t");
		}
		}else{
			System.out.println("\tInsufficient Balance");
		}

	}

	void fundtransfer() throws Exception {
		System.out.print("\n\tEnter Account ID to Transfer Money From\t:");
		int srcAccId = scanner.nextInt();

		AccountBean accountBean1 = service.findAccount(srcAccId);
		if (accountBean1 == null) {
			System.out.println("\n\tAccount Does not exist\n\t");
			return;
		}

		System.out.print("\n\t Account holder name \t:" + accountBean1.getCustomerBean().getFirstName() + "\n\t");
		System.out.print("\n\t Account holder's address \t:" + accountBean1.getCustomerBean().getAddress() + "\n\t");
		System.out.print("\n\t Current Balance \t:" + accountBean1.getBalance() + "\n\t");

		System.out.print("\n\tEnter Account ID to Transfer Money to\t:");
		int targetAccId = scanner.nextInt();

		AccountBean accountBean2 = service.findAccount(targetAccId);
		if (accountBean2 == null) {
			System.out.println("\n\tAccount Does not exist\n\t");
			return;
		}

		System.out.print("\n\t Account holder name \t:" + accountBean2.getCustomerBean().getFirstName() + "\n\t");
		System.out.print("\n\t Account holder's address \t:" + accountBean2.getCustomerBean().getAddress() + "\n\t");
		System.out.print("\n\t Current Balance \t:" + accountBean2.getBalance() + "\n\t");

		System.out.print("\n\tEnter amount that you want to transfer\t:");
		double transferAmt = scanner.nextDouble();
		if(transferAmt<accountBean1.getBalance()){
		WalletTransaction wt = new WalletTransaction();
		wt.setTransactionType("FundsTransfer(withdraw)");
		wt.setBalance(accountBean1.getBalance() - transferAmt);
		wt.setTransactionDate(new Date());
		wt.setTransactionAmt(transferAmt);
		wt.setBeneficiaryAccountBean(accountBean2);

		accountBean1.addTransation(wt);

		WalletTransaction wt1 = new WalletTransaction();
		wt1.setTransactionType("FundsTransfer(deposit)");
		wt1.setTransactionDate(new Date());
		wt.setBalance(accountBean1.getBalance() + transferAmt);
		wt1.setTransactionAmt(transferAmt);
		wt1.setBeneficiaryAccountBean(accountBean1);

		accountBean2.addTransation(wt1);
		
		double balance=service.fundTransfer(accountBean1, accountBean2, transferAmt);
		

		if (balance>=0) {
			System.out.print("\n\tMoney is transferred  from " + accountBean1.getCustomerBean().getFirstName()
					+ "'s Account \n\t");

			System.out.println("\n\tcurrent balance : " + accountBean1.getBalance() + "\n\t");
		} else {
			System.out.print("\n\tMoney is not transferred from " + accountBean1.getCustomerBean().getFirstName()
					+ "'s Account \n\t");
		}
		}else{
			System.out.println("\tInsufficient Balance");
		}
	}

	void printTransaction() throws Exception {
		System.out.print("\n\tEnter Account ID (for printing Transaction Details)\t:");
		int accId = scanner.nextInt();

		AccountBean accountBean = service.findAccount(accId);
		if(accountBean!=null){
		List<WalletTransaction> transactions = accountBean.getAllTransactions();
		System.out.println("\n------------------------------------------------------------------\n");

		System.out.print("Account Id\t:\t" + accountBean.getAccountId() + "\n");

		System.out.print("Name\t:\t" + accountBean.getCustomerBean().getFirstName() + "\n");

		System.out.print("Balance\t:\t" + accountBean.getBalance() + "\n");
		System.out.println("\n------------------------------------------------------------------\n");
		System.out.println("\tTransaction Type\t Transaction Date\t Amount \t Current Balance\t\n ");

		for (WalletTransaction wt : transactions) {
			System.out.println("\t" + wt.getTransactionType() + "\t" + wt.getTransactionDate() + "\t "
					+ wt.getTransactionAmt() + "\t " + wt.getBalance());

		}

		System.out.print("\n------------------------------------------------------------------\n");

	}else{
		System.out.println("\n\tAccount Does not exist\n\t");
		}
	}

}
